<html>
<head>
   <link href="style.css" rel="stylesheet" type="text/css">
   <meta http-equiv="content-type" content="text/html;">
   <title>Βάση Δεδομένων Points of Interest</title>
   <link rel="icon" type="image/x-icon" href="https://www.clipartmax.com/png/full/255-2552230_database-symbol-png-database-icon-flat.png">
</head>


<body>
    <h1>Βάση Δεδομένων Points of Interest</h1>

	
<h2>Επιλογές</h2>


<div id="navbar">
            <a href="http://hilon.dit.uop.gr/~db1u02/select.php">Προβολή βάσης</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/insert_users.php">Εισαγωγή δεδομένων στους Χρήστες</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/insert_city.php">Εισαγωγή δεδομένων στις Πόλεις</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/insert_poi.php">Εισαγωγή δεδομένων στα Σημεία Ενδιαφέροντος</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/delete_users.php">Διαγραφή δεδομένων στους Χρήστες</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/delete_city.php">Διαγραφή δεδομένων στις Πόλεις</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/delete_poi.php">Διαγραφή δεδομένων στα Σημεία Ενδιαφέροντος</a>
</div>

</body>

</html>
