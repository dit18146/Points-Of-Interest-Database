<html>
<head>
   <link href="style.css" rel="stylesheet" type="text/css">
   <meta http-equiv="content-type" content="text/html;">
   <title>Επίλεξε βάση</title>
   <link rel="icon" type="image/x-icon" href="https://www.clipartmax.com/png/full/255-2552230_database-symbol-png-database-icon-flat.png">
</head>


<body>
    <h1>Επίλεξε βάση</h1>
    
<h2>Επιλογές</h2>


<div id="navbar">
            <a href="http://hilon.dit.uop.gr/~db1u02/view_users.php">Προβολή βάσης Χρήστες</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_city.php">Προβολή βάσης Πόλεις</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_poi.php">Προβολή βάσης Σημεία Ενδιαφέροντος (1)</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_2.1.php">2.1</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_2.2.php">Προβολή στοιχεία των χρηστών ανά πόλη με αλφαβητική σειρά (2.2)</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_3.php">Προβολή χρηστών και χωρών (3)</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_4.php">Παρουσίαση κατηγοριών (4)</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.1.php">5.1</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.2.php">5.2</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.3.php">5.3</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.4.php">5.4</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.5.php">5.5</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.6.php">5.6</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.7.php">5.7</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.8.php">5.8</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.9.php">5.9</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.10.php">5.10</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.11.php">5.11</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.12.php">5.12</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.13.php">5.13</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.14.php">5.14</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.15.php">5.15</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.16.php">5.16</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.17.php">5.17</a>
            <a href="http://hilon.dit.uop.gr/~db1u02/view_5.18.php">5.18</a>
</div>

</body>

</html>
